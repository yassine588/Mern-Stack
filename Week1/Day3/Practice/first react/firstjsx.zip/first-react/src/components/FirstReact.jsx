import React from 'react'
const FirstReact = () => {
  return (
    <div>
    <h1>Hello Dojo</h1>
    <h2>Things I need to do:</h2>
    <p>*Learn React</p>
    <p>*Climb Mt. Everst</p>
    <p>*Run a marathon</p>
    <p>*Feed the dogs</p>
    </div>
  )
}

export default FirstReact