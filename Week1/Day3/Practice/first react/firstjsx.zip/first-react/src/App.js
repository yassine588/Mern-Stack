import './App.css';
import FirstReact from './components/FirstReact';
function App() {
  return (
    <div className="App">
   <FirstReact />
    </div>
  );
}

export default App;
